// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"config.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.YOUR_API_KEY = exports.DEFAULT_MAP_ZOOM_LEVEL = void 0;
var YOUR_API_KEY = "AIzaSyANju-0rURjpzrd7cgN54atuefazRE1qxk";
exports.YOUR_API_KEY = YOUR_API_KEY;
var DEFAULT_MAP_ZOOM_LEVEL = 16;
exports.DEFAULT_MAP_ZOOM_LEVEL = DEFAULT_MAP_ZOOM_LEVEL;
},{}],"helpers.js":[function(require,module,exports) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var distance = function distance(firstCoords, secondCoords) {
  if (firstCoords[0] == secondCoords[0] && firstCoords[1] == secondCoords[1]) {
    return 0;
  } else {
    var radlat1 = Math.PI * firstCoords[0] / 180;
    var radlat2 = Math.PI * secondCoords[0] / 180;
    var theta = firstCoords[1] - secondCoords[1];
    var radtheta = Math.PI * theta / 180;
    var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);

    if (dist > 1) {
      dist = 1;
    }

    dist = Math.acos(dist);
    dist = dist * 180 / Math.PI;
    dist = dist * 60 * 1.1515;
    dist = dist * 1.609344;
    return dist;
  }
};

var _default = distance;
exports.default = _default;
},{}],"index.js":[function(require,module,exports) {
"use strict"; // import "core-js/stable";
// import "regenerator-runtime/runtime";

var _config = require("./config.js");

var _helpers = _interopRequireDefault(require("./helpers.js"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _classPrivateMethodInitSpec(obj, privateSet) { _checkPrivateRedeclaration(obj, privateSet); privateSet.add(obj); }

function _classPrivateFieldInitSpec(obj, privateMap, value) { _checkPrivateRedeclaration(obj, privateMap); privateMap.set(obj, value); }

function _checkPrivateRedeclaration(obj, privateCollection) { if (privateCollection.has(obj)) { throw new TypeError("Cannot initialize the same private elements twice on an object"); } }

function _classPrivateFieldSet(receiver, privateMap, value) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "set"); _classApplyDescriptorSet(receiver, descriptor, value); return value; }

function _classApplyDescriptorSet(receiver, descriptor, value) { if (descriptor.set) { descriptor.set.call(receiver, value); } else { if (!descriptor.writable) { throw new TypeError("attempted to set read only private field"); } descriptor.value = value; } }

function _classPrivateFieldGet(receiver, privateMap) { var descriptor = _classExtractFieldDescriptor(receiver, privateMap, "get"); return _classApplyDescriptorGet(receiver, descriptor); }

function _classExtractFieldDescriptor(receiver, privateMap, action) { if (!privateMap.has(receiver)) { throw new TypeError("attempted to " + action + " private field on non-instance"); } return privateMap.get(receiver); }

function _classApplyDescriptorGet(receiver, descriptor) { if (descriptor.get) { return descriptor.get.call(receiver); } return descriptor.value; }

function _classPrivateMethodGet(receiver, privateSet, fn) { if (!privateSet.has(receiver)) { throw new TypeError("attempted to get private field on non-instance"); } return fn; }

// import axios from "axios";
var inputSearch = document.querySelector(".address-input--");
var address = document.querySelector(".address-div");
var helpForm = document.querySelector(".helper-form");
var helpBtn = document.querySelector(".help-btn");
var msgSvg = document.querySelector(".tawk-min-chat-icon");
var Tawk_API = Tawk_API || {},
    Tawk_LoadStart = new Date();

(function () {
  var s1 = document.createElement("script"),
      s0 = document.getElementsByTagName("script")[0];
  s1.async = true;
  s1.src = "https://embed.tawk.to/62f4ab5437898912e962634f/1ga5rqgvh";
  s1.charset = "UTF-8";
  s1.setAttribute("crossorigin", "*");
  s0.parentNode.insertBefore(s1, s0);
})();

if (msgSvg) {
  msgSvg.style.color = "#c92a2a";
}

var _lat = /*#__PURE__*/new WeakMap();

var _lng = /*#__PURE__*/new WeakMap();

var _mapCoords = /*#__PURE__*/new WeakMap();

var _map = /*#__PURE__*/new WeakMap();

var _theHospitals = /*#__PURE__*/new WeakMap();

var _policeStations = /*#__PURE__*/new WeakMap();

var _getPosition = /*#__PURE__*/new WeakSet();

var _loadMap = /*#__PURE__*/new WeakSet();

var _rejectedMap = /*#__PURE__*/new WeakSet();

var _nearestLocationPopup = /*#__PURE__*/new WeakSet();

var _myBtn = /*#__PURE__*/new WeakSet();

var _findNearestLocation = /*#__PURE__*/new WeakSet();

var MapApp = /*#__PURE__*/_createClass(function MapApp() {
  _classCallCheck(this, MapApp);

  _classPrivateMethodInitSpec(this, _findNearestLocation);

  _classPrivateMethodInitSpec(this, _myBtn);

  _classPrivateMethodInitSpec(this, _nearestLocationPopup);

  _classPrivateMethodInitSpec(this, _rejectedMap);

  _classPrivateMethodInitSpec(this, _loadMap);

  _classPrivateMethodInitSpec(this, _getPosition);

  _classPrivateFieldInitSpec(this, _lat, {
    writable: true,
    value: void 0
  });

  _classPrivateFieldInitSpec(this, _lng, {
    writable: true,
    value: void 0
  });

  _classPrivateFieldInitSpec(this, _mapCoords, {
    writable: true,
    value: []
  });

  _classPrivateFieldInitSpec(this, _map, {
    writable: true,
    value: void 0
  });

  _classPrivateFieldInitSpec(this, _theHospitals, {
    writable: true,
    value: {
      mustafa_Hospital: [35.3375644152962, 33.32549467087968],
      ozel_Hospital: [35.199931664594054, 33.32767263083378],
      neu_Hospital: [35.228246396588766, 33.31967681080006],
      kolan_Hospital: [35.20915404705675, 33.31677212894438],
      komiloglu_Hospital: [35.33654259651031, 33.31034555302767],
      lefkeCengiz_Hospital: [35.157420221003235, 32.868094709917415],
      gazimagusaDevlet_Hospital: [35.15487202919007, 33.90366343029331]
    }
  });

  _classPrivateFieldInitSpec(this, _policeStations, {
    writable: true,
    value: {
      kyrenia_PD: [35.34600473831902, 33.31557894013235],
      nicosia_PD: [35.18811628345015, 33.36258636602645],
      morphou_PD: [35.2009606194846, 32.98901299751162],
      trCypriot_PD: [35.19263270101967, 33.360189826346726],
      omorfita_PD: [35.17958607110221, 33.38979512184739],
      ercan_PD: [35.15847818188118, 33.50475045518113],
      alaykoy_PD: [35.183854893170285, 33.25614426879475],
      lidras_PD: [35.174876596027495, 33.361479697629804]
    }
  });

  _classPrivateMethodGet(this, _getPosition, _getPosition2).call(this);

  helpForm.addEventListener("submit", _classPrivateMethodGet(this, _myBtn, _myBtn2).bind(this));
}
/**
 * gets current position of the user's navigator.geolocation
 */
);

function _getPosition2() {
  navigator.geolocation.getCurrentPosition(_classPrivateMethodGet(this, _loadMap, _loadMap2).bind(this), _classPrivateMethodGet(this, _rejectedMap, _rejectedMap2));
}

function _loadMap2(pos) {
  var position = pos.coords;
  var latitude = position.latitude,
      longitude = position.longitude;

  _classPrivateFieldGet(this, _mapCoords).push(latitude, longitude);

  helpBtn.setAttribute("href", "/maplocation?location=".concat(latitude, "-").concat(longitude)); // set map

  _classPrivateFieldSet(this, _map, L.map("map").setView(_classPrivateFieldGet(this, _mapCoords), _config.DEFAULT_MAP_ZOOM_LEVEL)); // set tileLayer


  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(_classPrivateFieldGet(this, _map));
  L.Control.geocoder().addTo(_classPrivateFieldGet(this, _map)); // adding marker to the current position

  L.marker(_classPrivateFieldGet(this, _mapCoords)).addTo(_classPrivateFieldGet(this, _map)).bindPopup(L.popup({
    maxWidth: 250,
    minWidth: 50,
    autoClose: false,
    closeOnClick: false
  })).setPopupContent("Do not panic. Click Help!!!").openPopup();
  L.circle(_classPrivateFieldGet(this, _mapCoords), {
    color: "red",
    fillColor: "#f03",
    fillOpacity: 0.5,
    radius: 30
  }).addTo(_classPrivateFieldGet(this, _map));
}

function _rejectedMap2() {
  alert("Please allow access to your Current location");
}

function _nearestLocationPopup2(helpwith) {
  var options = {}; // const [lat, lng] = this.#findNearestLocation(helpwith)[2];

  L.marker(_classPrivateMethodGet(this, _findNearestLocation, _findNearestLocation2).call(this, helpwith)[0]).addTo(_classPrivateFieldGet(this, _map)).bindPopup(L.popup({
    maxWidth: 250,
    minWidth: 50,
    autoClose: false,
    closeOnClick: false
  })).setPopupContent(_classPrivateMethodGet(this, _findNearestLocation, _findNearestLocation2).call(this, helpwith)[1]).openPopup();
}

function _myBtn2(e) {
  e.preventDefault();
  var theInputCheck = inputSearch.value;
  var theInputCheckComp = theInputCheck.toLowerCase().trim();

  if (theInputCheckComp === "hospital") {
    _classPrivateMethodGet(this, _nearestLocationPopup, _nearestLocationPopup2).call(this, _classPrivateFieldGet(this, _theHospitals));
  } else if (theInputCheckComp === "police") {
    _classPrivateMethodGet(this, _nearestLocationPopup, _nearestLocationPopup2).call(this, _classPrivateFieldGet(this, _policeStations));
  } else {
    alert("Please enter the correct emergency you need help with");
  }
}

function _findNearestLocation2(helpwith) {
  var _this = this;

  // create an empty list to put the calculated distance of each result of your coordinates and other hospital coordinates
  var arr = []; // convert the hospital object to an entries array

  var convertEntry = Object.entries(helpwith); // loop through the hospitals entries coordinates array and call the distance function

  convertEntry.forEach(function (theEntry) {
    arr.push((0, _helpers.default)(_classPrivateFieldGet(_this, _mapCoords), theEntry[1]));
  }); // find the smallest distance to your current coordinates

  var themin = Math.min.apply(Math, arr); // find the index of the smallest distance in the created array
  // NOTE: since the forEach method is checking for every arrays in the hospital list...
  // ...the result of the distance would be perfectly positioned in the same index as the hospital list...
  // ... which is why we can use the findIndex method to get position of the smallest distance index

  var theminDisIndex = arr.findIndex(function (dis) {
    return dis === themin;
  }); // return the coordinate of the smallest distance that was calculated
  // manipulate the key of the closest location and convert it to a string

  var popUpname = convertEntry[theminDisIndex][0];
  var splitPopup = popUpname.split("_").map(function (el) {
    return el.replace(el[0], el[0].toUpperCase());
  }).join(" "); //return the key and value of the smallest distance calculated

  return [convertEntry[theminDisIndex][1], splitPopup, convertEntry[theminDisIndex][1]];
}

var app = new MapApp();
},{"./config.js":"config.js","./helpers.js":"helpers.js"}],"../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js":[function(require,module,exports) {
var global = arguments[3];
var OVERLAY_ID = '__parcel__error__overlay__';
var OldModule = module.bundle.Module;

function Module(moduleName) {
  OldModule.call(this, moduleName);
  this.hot = {
    data: module.bundle.hotData,
    _acceptCallbacks: [],
    _disposeCallbacks: [],
    accept: function (fn) {
      this._acceptCallbacks.push(fn || function () {});
    },
    dispose: function (fn) {
      this._disposeCallbacks.push(fn);
    }
  };
  module.bundle.hotData = null;
}

module.bundle.Module = Module;
var checkedAssets, assetsToAccept;
var parent = module.bundle.parent;

if ((!parent || !parent.isParcelRequire) && typeof WebSocket !== 'undefined') {
  var hostname = "" || location.hostname;
  var protocol = location.protocol === 'https:' ? 'wss' : 'ws';
  var ws = new WebSocket(protocol + '://' + hostname + ':' + "60350" + '/');

  ws.onmessage = function (event) {
    checkedAssets = {};
    assetsToAccept = [];
    var data = JSON.parse(event.data);

    if (data.type === 'update') {
      var handled = false;
      data.assets.forEach(function (asset) {
        if (!asset.isNew) {
          var didAccept = hmrAcceptCheck(global.parcelRequire, asset.id);

          if (didAccept) {
            handled = true;
          }
        }
      }); // Enable HMR for CSS by default.

      handled = handled || data.assets.every(function (asset) {
        return asset.type === 'css' && asset.generated.js;
      });

      if (handled) {
        console.clear();
        data.assets.forEach(function (asset) {
          hmrApply(global.parcelRequire, asset);
        });
        assetsToAccept.forEach(function (v) {
          hmrAcceptRun(v[0], v[1]);
        });
      } else if (location.reload) {
        // `location` global exists in a web worker context but lacks `.reload()` function.
        location.reload();
      }
    }

    if (data.type === 'reload') {
      ws.close();

      ws.onclose = function () {
        location.reload();
      };
    }

    if (data.type === 'error-resolved') {
      console.log('[parcel] ✨ Error resolved');
      removeErrorOverlay();
    }

    if (data.type === 'error') {
      console.error('[parcel] 🚨  ' + data.error.message + '\n' + data.error.stack);
      removeErrorOverlay();
      var overlay = createErrorOverlay(data);
      document.body.appendChild(overlay);
    }
  };
}

function removeErrorOverlay() {
  var overlay = document.getElementById(OVERLAY_ID);

  if (overlay) {
    overlay.remove();
  }
}

function createErrorOverlay(data) {
  var overlay = document.createElement('div');
  overlay.id = OVERLAY_ID; // html encode message and stack trace

  var message = document.createElement('div');
  var stackTrace = document.createElement('pre');
  message.innerText = data.error.message;
  stackTrace.innerText = data.error.stack;
  overlay.innerHTML = '<div style="background: black; font-size: 16px; color: white; position: fixed; height: 100%; width: 100%; top: 0px; left: 0px; padding: 30px; opacity: 0.85; font-family: Menlo, Consolas, monospace; z-index: 9999;">' + '<span style="background: red; padding: 2px 4px; border-radius: 2px;">ERROR</span>' + '<span style="top: 2px; margin-left: 5px; position: relative;">🚨</span>' + '<div style="font-size: 18px; font-weight: bold; margin-top: 20px;">' + message.innerHTML + '</div>' + '<pre>' + stackTrace.innerHTML + '</pre>' + '</div>';
  return overlay;
}

function getParents(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return [];
  }

  var parents = [];
  var k, d, dep;

  for (k in modules) {
    for (d in modules[k][1]) {
      dep = modules[k][1][d];

      if (dep === id || Array.isArray(dep) && dep[dep.length - 1] === id) {
        parents.push(k);
      }
    }
  }

  if (bundle.parent) {
    parents = parents.concat(getParents(bundle.parent, id));
  }

  return parents;
}

function hmrApply(bundle, asset) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (modules[asset.id] || !bundle.parent) {
    var fn = new Function('require', 'module', 'exports', asset.generated.js);
    asset.isNew = !modules[asset.id];
    modules[asset.id] = [fn, asset.deps];
  } else if (bundle.parent) {
    hmrApply(bundle.parent, asset);
  }
}

function hmrAcceptCheck(bundle, id) {
  var modules = bundle.modules;

  if (!modules) {
    return;
  }

  if (!modules[id] && bundle.parent) {
    return hmrAcceptCheck(bundle.parent, id);
  }

  if (checkedAssets[id]) {
    return;
  }

  checkedAssets[id] = true;
  var cached = bundle.cache[id];
  assetsToAccept.push([bundle, id]);

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    return true;
  }

  return getParents(global.parcelRequire, id).some(function (id) {
    return hmrAcceptCheck(global.parcelRequire, id);
  });
}

function hmrAcceptRun(bundle, id) {
  var cached = bundle.cache[id];
  bundle.hotData = {};

  if (cached) {
    cached.hot.data = bundle.hotData;
  }

  if (cached && cached.hot && cached.hot._disposeCallbacks.length) {
    cached.hot._disposeCallbacks.forEach(function (cb) {
      cb(bundle.hotData);
    });
  }

  delete bundle.cache[id];
  bundle(id);
  cached = bundle.cache[id];

  if (cached && cached.hot && cached.hot._acceptCallbacks.length) {
    cached.hot._acceptCallbacks.forEach(function (cb) {
      cb();
    });

    return true;
  }
}
},{}]},{},["../../node_modules/parcel-bundler/src/builtins/hmr-runtime.js","index.js"], null)
//# sourceMappingURL=/finals.js.map